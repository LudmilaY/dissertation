import pymysql

# Configuração da conexão com o banco de dados
conexao = pymysql.connect(
    host='localhost',
    port=3309,
    user='root',
    password='ohmy5_',
    database='teste'
)

try:
    # Create a cursor object
    with conexao.cursor() as cursor:
        # SQL query
        sql_query = "SELECT * from patients WHERE subject_id = %s;"

        # Execute the query
        cursor.execute(sql_query, ("42292",)) #cursor.execute(sql_query, ("42292",)) EXAMPLE

        # Fetch all the results
        results = cursor.fetchall()

        # Process the results
        for row in results:
            print(row)

finally:
    # Close the connection
    conexao.close()
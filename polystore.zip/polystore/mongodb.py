from pymongo import MongoClient

# Conectar ao servidor MongoDB (certifique-se de ter um servidor MongoDB em execução)
client = MongoClient('localhost', 27017)

# Selecionar o banco de dados e a coleção
db = client['prescriptions']
colecao = db['healthCare']

# Consulta simples
#resultado = colecao.find({"row_id": "subject_id", "hadm_id": "icustay_id", "startdate": "enddate", "drug_type": "drug", "drug_name_poe": "drug_name_generic", "formulary_drug_cd": "gsn", "ndc": "prod_strength", "dose_val_rx": "dose_unit_rx", "form_val_disp": "form_unit_disp", "route": "subject_id"})
resultado = colecao.find({"subject_id": 42458})

# Exibindo os resultados
for documento in resultado:
    print(documento)

# Fechar a conexão com o MongoDB
client.close()
import pandas as pd

# Load the CSV file into a DataFrame
df = pd.read_csv('C:/Users/lud_y/Downloads/Dissertação/Dados/mimic-iii-clinical-database-demo-1.4/mimic-iii-clinical-database-demo-1.4/CHARTEVENTS.csv', sep=',', index_col=False, dtype='unicode')

# Display the DataFrame
#print(df)

#import csv

#def insert_into_csv(filename, data):
    # Open the CSV file in append mode
    #with open(filename, 'a', newline='') as file:
    #    writer = csv.writer(file)
        # Write the data to the CSV file
    #    writer.writerow(data)

# Example usage:
#filename = 'data.csv'
#data_to_insert = ['John', 30, 'New York']  # Example data to insert into the CSV file
#insert_into_csv(filename, data_to_insert)
